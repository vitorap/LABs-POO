##Pratica 4
===================================

Para executar, rode primeiro o server, depois o cliente

No cliente, escrever as mensagens na caixa superior.

Pode conectar até 100 clientes

a caixa do meio, ira mostrar o chat entre todos clientes

A caixa inferior ira mostrar as mensagens enviadas codificadas

O servidor ira mostrar informaçoes sobre oque esta acontecendo