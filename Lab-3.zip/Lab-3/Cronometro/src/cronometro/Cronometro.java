package cronometro;

/**
 *
 * @author vitor
 */
public class Cronometro {

  
    public static void main(String[] args) {
        
        CronometroInterface cro = new CronometroInterface();
        
        cro.setVisible(true);
        
    }
    
}
