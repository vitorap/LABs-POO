/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.brunotome.lab2;

/**
 *
 * @author brunorosa
 */
public class Principal {
    public static void main(String [] args){
    Lista lista;
    Usuario usu = new Usuario("Gustavo");
    lista = new ListaEncadeada();
    lista.inserir(new Usuario("Marcelo"));
    lista.inserir(new Usuario("Joao"));
    lista.inserir(new Usuario("Pedro"));
    lista.inserir(new Usuario("Gustavo"));
    lista.inserir(new Usuario("Larissa"));
    lista.inserir(new Usuario("Flavia"));
    lista.imprimir();
    lista.remover(new Usuario("Gustavo"));
    lista.imprimir();
    
    
    
    
    }
    
    
}
