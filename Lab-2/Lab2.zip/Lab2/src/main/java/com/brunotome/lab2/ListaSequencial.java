/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.brunotome.lab2;
import java.util.*;
/**
 *
 * @author brunorosa
 */
public class ListaSequencial extends Lista{
    IElemento[] data = new IElemento[100];
    
    ListaSequencial(){
        for(int i = 0; i < this.data.length; i++){
            this.data[i] = null;
        }
        tamanho();
    }
    
    
    
    @Override
    public int tamanho() {
        int cont = 0;
        for(IElemento atual: this.data){
            if(atual == null){
                break;
            }else{
                cont++;
                
            }
            
        }
        this.tamanho = cont;
        
        return this.tamanho;
    }

    @Override
    public void inserir(IElemento elem) {
        
        for(int i = 0; i <= this.tamanho ;i++){
            
            if(this.data[i] == null){
                this.data[i] = elem;
                break;
            }
        }
        tamanho();
    }

    @Override
    public void remover(IElemento elem) {
        
        int i;
        for(i = 0; i <= this.tamanho ;i++){
            
            if(java.util.Objects.equals(this.data[i], null)){
                this.data[i] = this.data[i+1];
                this.data[i+1] = null;
            }else{
                if(elem.equals(this.data[i])){
                    this.data[i] = this.data[i+1];
                    this.data[i+1] = null;
                }
            }
            
        }
        tamanho();
    }

    @Override
    public void imprimir() {
        IElemento atual;
        for(int i = 0; i < this.tamanho ;i++){
            atual = this.data[i];
            if(atual == null){System.out.println("null" + " ");}else{
            System.out.print(atual.toString()+ " ");
            }
            }
        System.out.print("\n");
        }
    }
   
    
    

