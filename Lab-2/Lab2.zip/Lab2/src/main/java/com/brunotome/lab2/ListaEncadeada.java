/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.brunotome.lab2;
import java.util.*;
/**
 *
 * @author brunorosa
 */
public class ListaEncadeada extends Lista{
    No raiz;
    No topo;
    ListaEncadeada(){
    this.raiz = (No)null;
    this.topo = (No)null;
    }
    
    @Override
    public int tamanho() {
        No no = this.raiz;
        int cont = 0;
        int i = 0;
        while(!no.equals(null)){
        cont++;
        no = no.next;
        }
        this.tamanho = cont;
        return this.tamanho;
    }

    @Override
    public void inserir(IElemento elem) {
        if(this.raiz == (No)null){
            No no = new No();
            no.setElemento(elem);
            this.raiz = no;
            this.topo = no;
        }else{
        No no = new No();
        no.setElemento(elem);
        this.topo.next = no;
        this.topo = no;
        }
        
               
    }

    @Override
    public void remover(IElemento elem) {
       No atual = this.raiz;
       No ant = atual;
       while(this.topo != atual){
           if(elem.equals(atual.getELemento())){
               ant.next = atual.next;
               break;
            }


           ant = atual;
           atual = atual.next;
       }
       
    }

    @Override
    public void imprimir() {
        No no = this.raiz;
        if(this.raiz == null){return;}else{
            while(!(no == null)){
             System.out.print(no.getELemento() + " ");
             no = no.next;
            }
            System.out.println();
            
        
        }
       
            }
    
}
