/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cronometro;

/**
 *
 * @author ICMC
 */
public class Cronometro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        CronometroInterface cro = new CronometroInterface();
        
        cro.setVisible(true);
        
    }
    
}
