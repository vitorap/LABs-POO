/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.brunotome.sistemabiblio;
import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

/**
 *
 * @author brunorosa
 */
public class UserBase {
   
    ArrayList <Usuario> UsrBase = new <Usuario> ArrayList(); 
    Iterator itr = UsrBase.iterator();
    UserBase(){ // contructor
    
    }
    public ArrayList <Usuario> init(){
        return this.UsrBase;
    }
    
    public void printUsrB(){
        Usuario usr;
        for(int i = 0 ;i < this.UsrBase.size(); i++ ){
         usr = this.UsrBase.get(i);
         System.out.println(usr.Nome + " " + usr.DataNasc + " " + usr.nUsp);
        }
    }
    
    
    public Usuario createUsr(UserBase usrb){
       SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
       Usuario usuario = new Usuario();
       Scanner myObj = new Scanner(System.in);
       System.out.println("\nEscreva o nome do usuario,data de nascimento(dd/mm/yy) e o número Usp:\n");
       String name;
       String nac;
       int nu = 0;
       int flag = -1;
       String adr[] = new String[3];        
       name = myObj.nextLine();
       nac = myObj.nextLine();
       Date Nasc = null;
       try { // formatação dos dados de nasc
            Nasc = format.parse(nac);
            
        } catch (ParseException e) {
            e.printStackTrace();
        }
       
       while(flag != 1){ // validação de dados do nusp
          nu = Integer.parseInt(myObj.nextLine());
          if(nu <= 9999999){flag = 1;}
          System.out.println("Digito muito Grande!");
         }
       System.out.println("\nEscreva a rua, numero e cidade de onde você mora:\n");
        for(int i = 0; i < 3;i++ ){
            adr[i] = myObj.nextLine();
        }
        
        usuario.inicializa(name, Nasc, nu, adr);
        
        this.UsrBase.add(usuario);
        
        return usuario;
        
       }
    
    public void cadastraNovo(Usuario usuario){
        this.UsrBase.add(usuario);
    }
    public int consulta(String string){ // Usado para consultar se existe o String no Autor|Titulo|Editor , retornando a posição caso exista, e se não, retornando -1 
       
        Usuario currUsr;
        int indexOf = -1;

      for(int i=0;i< this.UsrBase.size();i++)  
           {  
            currUsr = UsrBase.get(i);
            if(currUsr.Nome.contains(string) || currUsr.nUsp == (Integer.parseInt(string)) ){
                indexOf = UsrBase.indexOf(currUsr);
            }
           }
      if(indexOf == -1){
          System.out.println("Usuario não encontrado");
      }
        return indexOf;
    }
    public void remove(int index){ // remove midia de acervo
        try{
        if(index == -1){throw new IllegalArgumentException("Usuario não encontrado");
        }else{
       Usuario usuario;
        usuario = UsrBase.get(index);
        UsrBase.remove(usuario);
    }
        }
        catch(IllegalArgumentException ex){
            System.out.println(ex.getMessage());
            
        }
    }
    public Usuario recupera(int index){
        try{
        if(index == -1){throw new IllegalArgumentException("Usuario não encontrado");}
       Usuario usuario;
       usuario = UsrBase.get(index);
       return usuario;
        }
        catch(IllegalArgumentException ex){
            System.out.println(ex.getMessage());
            System.exit(0);
            
        }
        }
    
    
    
    
}
