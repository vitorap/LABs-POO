/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.brunotome.sistemabiblio;

/**
 *
 * @author brunorosa
 */
public class Midia {
    
    String titulo;
    String autor;
    int pubYr;
    String mediaType;
    String editor;
    String local[];
    Usuario Usuario;
    int emprestado = 0;
    
    Midia(){
        this.local = new String[2];
       }
    
    public void inicializa(String titulo, String autor,int pubYr,String mediaType,String editor,String local[]){
        this.titulo = titulo;
        this.autor = autor;
        this.editor = editor;
        this.pubYr = pubYr;
        this.mediaType = mediaType;
        for(int i = 0; i < 2; i++){
            this.local[i]= local[i];
        }   
        
    }
}
