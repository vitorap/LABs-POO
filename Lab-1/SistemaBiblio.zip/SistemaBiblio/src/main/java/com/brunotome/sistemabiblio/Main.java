/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.brunotome.sistemabiblio;

/**
 *
 * @author brunorosa
 */
import java.util.*;

public class Main {

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String stru;
        String strm;
        UserBase ub = new UserBase();
        Acervo ac = new Acervo();
        while(true){
        System.out.println("\n\nOlá! Seja bem vindx ao DÆDALUS 2.0!\n Selecione Seu modo:\n1 - insercao de usuarios\n2 - insercao de midias\n3 - emprestimo de livros\n4 - devolucao de livros\n5 - Consulta de Midias\n6 - sair");
        
        Scanner mode = new Scanner(System.in);
        int a = Integer.parseInt(mode.nextLine()); 
        switch(a){
            case(1):
                ub.createUsr(ub);
                ub.printUsrB();
                break;
            case(2):
                ac.createMidia(ac);
                ac.printAcervo();
                break;
                
            case(3):
                System.out.println("Digite o nome do usuario");
                 stru = mode.nextLine();
                System.out.println("Digite o nome da midia");
                 strm = mode.nextLine();
                ac.empresta(ub,ac,stru,strm);
                break;
            case(4):
                System.out.println("Digite o nome do usuario");
                stru = mode.nextLine();
                System.out.println("Digite o nome da midia");
                strm = mode.nextLine();
                ac.devolve(ub,ac,stru,strm);
                break;
            case(5):
                 System.out.println("Digite o nome ou parte do nome da midia que deseja procurar:");
                 strm = mode.nextLine();
                 ac.print(ac.recupera(ac.consulta(strm)));
                break;
            case(6):
                System.exit(0);
            default:
                break;
             
            }
        }    
    }
 }
